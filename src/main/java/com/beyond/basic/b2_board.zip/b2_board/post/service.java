package com.beyond.basic.b2_board.post;

public class service {
}
