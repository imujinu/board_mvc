package com.beyond.basic.b2_board.author.domain;

public enum Role {
    ADMIN,USER;
}
