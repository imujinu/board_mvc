package com.beyond.basic.b2_board.post.repository;

import com.beyond.basic.b2_board.author.domain.Author;
import com.beyond.basic.b2_board.post.domain.Post;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostRepository extends JpaRepository<Post, Long> {
    // select * from post where author_id = ? and title =?
//    List<Post> findByAuthorIdAndTitle(Long id, String title);

    // select * from post where author_id = ? and title = ? order by createdTime desc;
    //    List<Post> findByAuthorIdAndTitleOrderByCreatedTimeDesc(Long id, String title);

    //변수명은 Author지만 AuthorId로도 조회 가능
    List<Post> findByAuthorId(Long id);


    List<Post> findByAuthor(Author author);
}
